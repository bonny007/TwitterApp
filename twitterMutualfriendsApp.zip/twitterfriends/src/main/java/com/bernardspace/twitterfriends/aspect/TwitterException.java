package com.bernardspace.twitterfriends.aspect;

public class TwitterException extends RuntimeException{

	public TwitterException(String message) {
		super(message);
	}
	
}
